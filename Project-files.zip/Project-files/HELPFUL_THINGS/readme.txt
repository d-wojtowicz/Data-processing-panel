# REQUIREMENTS:
Python version: 3.11.4


# IDEA:
1. Aplikacja filtrująca zbiory danych
    - MERYTORYKA: Seaborn, Pandas
    - GUI: Gradio
    - FUNKCJE:
        - Import/Eksport do .txt oraz .excel (*Być może też do .sql)
        - Filtrowanie według danych i warunków (pole do wprowadzenia/rosnące/malejące/normalnie/konkretnie),
        - Analiza statystyczna (MEAN, STD, MIN, MAX, Q1, Q2, Q3, Q4, wartości odstające),
        - Korelacja między dwiema kolumnami,
