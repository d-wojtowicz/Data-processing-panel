import pandas as pd

from utils.pandas_extension import *
from utils.data_stats_calculator import *
from utils.data_exporter import *

from source.data_reader import *

df_seaborn_reader = DataReader("diamonds", "seaborn", read_from.TOP, read_by.NORMAL, 10)
readed_df = df_seaborn_reader.read_data()

queried_df = get_df_by_query(readed_df, 'depth', 64.5, '>=')
category_queried_df = get_df_by_category(readed_df, 'cut', ['Good', 'Fair'])

print(readed_df)
print("\n\n")
print(queried_df)
print("\n\n")
print(category_queried_df)






# SKLEARN PROCCESSING
#df_sklearn_reader = DataReader("diabetes", "sklearn", read_from.BOTTOM, read_by.COLUMNS, 8)
#df2 = read_df_from_sklearn()



# PART 3A, Tworzymy KLASĘ MENEDŻER DANYCH
# ALE NAJPIERW PRZEROBIĆ KLASĘ READ_DF_FROM_SKLEARN tak aby czytała na rózne sposoby bądź tylko na normalny