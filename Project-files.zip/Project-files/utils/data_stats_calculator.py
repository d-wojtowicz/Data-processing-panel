import time #Pomiar czasu funkcji
import sys  #Pomiar wielkości obiektu
import pandas as pd
import seaborn as sns

from source.data_reader import *

class calc:
    @staticmethod
    def timeMeasure(func):
        t_start = time.process_time()
        eval(func)
        t_end = time.process_time()
        return t_end - t_start

    @staticmethod
    def sizeMeasure(obj):
        return sys.getsizeof(eval(obj)) #[Bytes]
    

    # Tak powinno byc ale nei dziala do konca
""" class calc:
    @staticmethod
    def timeMeasure(func):
        print("S")
        def wrapper(*args, **kwargs):
            t_start = time.process_time()
            print(str(func))
            t_end = time.process_time()
            return t_end - t_start
        return wrapper

    @staticmethod
    def sizeMeasure(obj):
        def wrapper(*args, **kwargs):
            return sys.getsizeof(obj(*args, **kwargs)) #[Bytes]
        return wrapper """